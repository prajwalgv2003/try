class AppImages {
  static String splash = "assets/images/splash-removebg-preview.png";
  static String home = "assets/images/splash-removebg-preview.png";
}
