import 'package:flutter/material.dart';

class AppColors {
  static Color colorFF = const Color(0xFFFFFFFF);
  static Color color54 = const Color(0xFF545454);
  static Color color3B = const Color(0xFFFCD13B);
  static Color colorD9 = const Color(0xFFD9D9D9);
  static Color color6F = const Color(0xFF65696F);
}
